#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "aviStruct.h"

int     main(void)
{
    gmavi_static_t a;
    gmavi_static_refs_t refs;
    FILE    *out;

    memset(&a, 0, sizeof(gmavi_static_t));
    out = fopen("test.avi", "wb+");
    a.main = (RIFFLIST){
        FOURCC_RIFF,
        0,
        FOURCC_TYPE_VIDEO
    };

    refs.cbMain = (BYTE *)&a.main.cb - (BYTE *)&a.main;
    a.hdrl = (RIFFLIST){
        FOURCC_LIST,
        4588,
        FOURCC_HEADER_LIST
    };

    a.aviHeader = (AVIMAINHEADER){
        FOURCC_AVI_HEADER,
        56,
        1000000 / 30,
        2560*1440*3*30,
        0x00000000,
        AVIF_HASINDEX,
        193,
        0,
        1,
        0,
        2560,
        1440
    };

    a.strl = (RIFFLIST){
        FOURCC_LIST,
        4244,
        FOURCC_STREAM_LIST
    };

    a.streamHeader = (AVISTREAMHEADER){
        FOURCC_STREAM_HEADER,
        56,
        FOURCC_STREAMTYPE_VIDS,
        FOURCC_HANDLER_DIB,
        0,
        0,
        0,
        0,
        1,
        30,
        0,
        250,
        2560*1440*3,
        0xFFFFFFFF,
        0,
        (RECT){0, 0, 2560, 1440}
    };
    
    a.strf = (RIFFCHUNK){
        FOURCC_STREAM_FORMAT,
        40,
    };
    
    a.bitmapHeader = (BITMAPINFOHEADER){
        40,
        2560,
        1440,
        1,
        24,
        0,
        2560 * 1440 * 3,
        0,
        0,
        0,
        0
    };

    a.superIndex = (AVISUPERINDEX){
        FOURCC_INDEX_DATA,
        4120,
        4,
        0,
        0,
        0,
        FOURCC_STREAM_RAW,
        NULL,
        NULL
    };
  
    //a.superIndex.index[0].offset = INT_MAX;
    //a.superIndex.index[0].duration = 10;
    //a.superIndex.index[0].size = 1000;
    refs.entriesInUse = (BYTE *)&a.superIndex.entriesInUse - (BYTE *)&a.main;

    a.odml = (RIFFLIST){
        FOURCC_LIST,
        260,
        FOURCC_EXTENDED_LIST
    };

    a.extendedHeader = (AVIEXTHEADER){
        FOURCC_EXTENDED_HEADER,
        248,
        250,
        NULL
    };

    a.junk = FOURCC_JUNK;
    a.junkSize = 0xDF8;

    a.movi = (RIFFLIST){
        FOURCC_LIST,
        0,
        FOURCC_MOVIE_DATA
    };
    refs.moviSize = (BYTE *)&a.movi.cb - (BYTE *)&a.main;

    DWORD filesize = (DWORD)fwrite(&a, 1, sizeof(gmavi_static_t), out);
    DWORD movisize = 4;
    for (int i = 0; i < 192; i++) {
        RGB24BITMAP bitstream;
        bitstream.fcc = FOURCC_STREAM_RAW;
        bitstream.cb = 2560*1440*3;
        BYTE *bitstream2 = (BYTE *)malloc(2560*1440*3);
        memset(bitstream2, (BYTE)128, 2560*1440*3);
        printf("%d\n", i);
        fwrite(&bitstream.fcc, 4, 1, out);
        fwrite(&bitstream.cb, 4, 1, out);
        fwrite(bitstream2, bitstream.cb, 1, out);
        movisize += 8 + bitstream.cb;
        filesize += 8 + bitstream.cb;
    }
    
    AVIOLDINDEX oldIndex = {
        FOURCC_TYPE_INDEX_OLD,
        192 * 16,
    };
    fwrite(&oldIndex, sizeof(oldIndex), 1, out);
    AVIOLDINDEX_ENTRY   *oldIndexEntries = (AVIOLDINDEX_ENTRY *)malloc(192 * sizeof(AVIOLDINDEX_ENTRY));
    for (int i = 0; i < 192; i++) {
        oldIndexEntries[i] = (AVIOLDINDEX_ENTRY){
            FOURCC_STREAM_RAW,
            AVIF_HASINDEX,
            4 + ((2560 * 1440 * 3) + 8) * i,
            (2560*1440*3) + 8
        };
    }
    filesize += 16 * 192;
    fwrite(oldIndexEntries, sizeof(AVIOLDINDEX_ENTRY), 192, out);
    
    

    RIFFLIST    nextMain = {
        FOURCC_RIFF,
        12,
        FOURCC_TYPE_VIDEO_EXT
    };
    fwrite(&nextMain, sizeof(RIFFLIST), 1, out);
    unsigned long nextMainBase = (BYTE *)&nextMain.cb - (BYTE *)&a.main;

    RIFFLIST    nextMovi = {
        FCC('LIST'),
        16,
        FCC('movi')
    };
    unsigned long nextMoviBase = (BYTE *)&nextMovi.cb - (BYTE *)&a.main;
    fwrite(&nextMovi, sizeof(RIFFLIST), 1, out);

    DWORD filesize2 = 16;
    DWORD movisize2 = 4;
    for (int i = 0; i < 250 - 192; i++) {
        RGB24BITMAP bitstream;
        bitstream.fcc = FOURCC_STREAM_RAW;
        bitstream.cb = 2560*1440*3;
        BYTE *bitstream2 = (BYTE *)malloc(2560*1440*3);
        memset(bitstream2, (BYTE)40, 2560*1440*3);
        printf("%d\n", i);
        fwrite(&bitstream.fcc, 4, 1, out);
        fwrite(&bitstream.cb, 4, 1, out);
        fwrite(bitstream2, bitstream.cb, 1, out);
        movisize2 += 8 + bitstream.cb;
        filesize2 += 8 + bitstream.cb;
    }


    fclose(out);
    DWORD hello = 10;
    out = fopen("test.avi", "rb+");
    fseek(out, refs.cbMain, SEEK_SET);
    //printf("%p\n", &hello);
    fwrite(&filesize, sizeof(DWORD), 1, out);
    fseek(out, refs.moviSize, SEEK_SET);
    fwrite(&movisize, sizeof(DWORD), 1, out);

    fseek(out, nextMainBase, SEEK_SET);
    fwrite(&filesize2, sizeof(DWORD), 1, out);

    fseek(out, nextMoviBase, SEEK_SET);
    fwrite(&movisize2, sizeof(DWORD), 1, out);
    fclose(out);
    //printf("%d\n", len);
    return 1;
}